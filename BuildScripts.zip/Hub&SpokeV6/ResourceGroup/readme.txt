Resource Group

main.tf: This Terraform code will Deploy Multiple Resource Groups.


backend.tf: backend stores Terraform state and may be used to run operations.where state snapshots are stored.


providers.tf : This file will store Providers details ,terraform Version and User Principle Details (Subscription ID,Tenent ID,ClClient_Secrets) and alias for Multi Subscription resource deployment.

