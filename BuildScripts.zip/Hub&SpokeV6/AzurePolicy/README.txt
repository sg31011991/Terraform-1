AZUREPOLICY

Add_tag_to_resources.tf :
This Terraform code will Create a Azure Policy for Add tag to resources
Add_tag_to_RG.tf :
This Terraform code will Create a Azure Policy for Add tag to resources groups.
allow_location_eastus_only :
This Terraform code will Create a Azure Policy for Allow Deploy Resources only Eastus.
inherit_tag_from_RG.tf :
This Terraform code will Create a Azure Policy inherit tags from resoure group
providers.tf : 
This file will store Providers details ,terraform Version and User Principle Details (Subscription ID,Tenent ID,ClClient_Secrets) and alias for Multi Subscription resource deployment.
Variable.tf: 
Variables in Terraform are a great way to define centrally controlled reusable values. The information in Terraform variables is saved independently from the deployment plans, which makes the values easy to read and edit from a single file.
backend.tf :
backend stores Terraform state and may be used to run operations.where state snapshots are stored.



