AZUREVAULT

main.tf:
This Terraform code will Deploy  Key Vault 
	Resource Group Creation for Keyvault
	Creating a Key Vault
  Need to enter Key Vault Secrate value and Password manually.

And, if required its can allow network_acls and Key vault access for object ID  to provide the access to another user.

backand.tf: backend stores Terraform state and may be used to run operations.where state snapshots are stored.


providers.tf : This file will store Providers details ,terraform Version and User Principle Details (Subscription ID,Tenent ID,ClClient_Secrets) and alias for Multi Subscription resource deployment.

Variable.tf: Variables in Terraform are a great way to define centrally controlled reusable values. The information in Terraform variables is saved independently from the deployment plans, which makes the values easy to read and edit from a single file.




$ AzureKeyVault
.
├── variable.tf               # store Providers details ,terraform Version and User Principle Details
├── main.tf                #  Terraform code will Deploy Resource Group,Storage account
├── providers.tf              # This file will store Providers details
├── backand.tf             #  backend stores Terraform state and may be used to run operations.