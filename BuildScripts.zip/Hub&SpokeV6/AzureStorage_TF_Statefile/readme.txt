AZURESTORAGE
________________________________________________________________________________________________________________
main.tf:
This Terraform code will Deploy  below Resources for Terraform State File  
	Create a Resource Group(Demo-TF-RG-1)
	Create a Storage account and Container(tf3101stgbknd1 and backend1)

state file will store inside the container(backend1)

backend "azurerm" {
        resource_group_name  = "Demo-TF-RG-1"
        storage_account_name = "tf3101stgbknd1"
        container_name       = "backend1"
        key                  = "state1.tfsate"
    }

__________________________________________________________________________________________________________________________
providers.tf : This file will store Providers details ,terraform Version and User Principle Details (Subscription ID,Tenent ID,ClClient_Secrets) and alias for Multi Subscription resource deployment.
__________________________________________________________________________________________________________________________
Variable.tf: Variables in Terraform are a great way to define centrally controlled reusable values. The information in Terraform variables is saved independently from the deployment plans, which makes the values easy to read and edit from a single file.
___________________________________________________________________________________________________________________________



$ AzureStorage_TF_Statefile
.
├── variable.tf               # store Providers details ,terraform Version and User Principle Details
├── main.tf                #  Terraform code will Deploy Resource Group,Storage account
├── providers.tf              # This file will store Providers details
├──              