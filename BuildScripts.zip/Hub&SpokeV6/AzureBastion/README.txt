AzureBastion
azurebastion.tf: This Terraform code will Create Below Resources.
	Pull the Resource Group information .
	Pull the Virtual Network information .
	Generate a Random Number for unique domain_name_label for Bestion Services.
	Pull the Subnets information 
	Create a Public IP for Azure Bastion Service.
	Deploy a Bastion Service host.
providers.tf : This file will store Providers details ,terraform Version and User Principle Details (Subscription ID,Tenent ID,ClClient_Secrets) and alias for Multi Subscription resource deployment.backand.tf : 

backand.tf: backend stores Terraform state and may be used to run operations.
where state snapshots are stored.

Variable.tf: Variables in Terraform are a great way to define centrally controlled reusable values. The information in Terraform variables is saved independently from the deployment plans, which makes the values easy to read and edit from a single file.

-------------------------------------------------------------------------------------------------------------
$ AZUREBASTION
.
├── azurebastion.tf              # Deploy a Bastin Services 
├── backand.tf                 # backend stores Terraform state and may be used to run operations.
├── providers.tf              # store Providers details ,terraform Version and User Principle Details 
├── variable.tf               # store resource value details 