AZURESTORAGE
________________________________________________________________________________________________________________
main.tf:
This Terraform code will Deploy  below Resources 
	Create a Resource Group
	Generate a Random Number for Stirage Unique String.
	Create a Storage account and Container

__________________________________________________________________________________________________________________________
providers.tf : This file will store Providers details ,terraform Version and User Principle Details (Subscription ID,Tenent ID,ClClient_Secrets) and alias for Multi Subscription resource deployment.backand.tf : 
__________________________________________________________________________________________________________________________
backand.tf: backend stores Terraform state and may be used to run operations.
where state snapshots are stored.
___________________________________________________________________________________________________________________________
Variable.tf: Variables in Terraform are a great way to define centrally controlled reusable values. The information in Terraform variables is saved independently from the deployment plans, which makes the values easy to read and edit from a single file.
___________________________________________________________________________________________________________________________
stgoutput: will Provide storage_account_id and primary_blob_endpoint.


$ AZUREBASTION
.
├── variable.tf               # store Providers details ,terraform Version and User Principle Details
├── backand.tf                # backend stores Terraform state and may be used to run operations.
├── providers.tf              # This file will store Providers details
├── main.tf              #  Terraform code will Deploy Resource Group,Storage account
      ├── .stgoutput.tf   # Provide the output.
